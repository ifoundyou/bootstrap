'use strict';

module.exports = {
  server: {
    options: {
      base: 'test',
      port: 9999
    }
  }
};