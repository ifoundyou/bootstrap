---
layout: default
title : Page inside +
permalink: /+/plus+in+url
---
Line 1
{{ page.title }}
