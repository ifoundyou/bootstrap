# Release History

## 0.3.1 / 06-01-2015
* Update deps, style consistency, badges [XhmikosR]

## 0.3.0 / 02-01-2015
* Added support for conditional banners via pattern [eirikhm]

## 0.2.3 / 27-05-2014
* Use examples for process functions

## 0.2.2 / 13-03-2014
* Update deps [XhmikosR]

## 0.2.1 / 17-02-2014
* Added processable banner creation function [pehrlich]

## 0.2.0 / 27-09-2013
* Added options.linebreak [janslow]
* Use grunt.utils.linefeed [evil-shrike]

## 0.1.4 / 01-05-2013
* Fix for wildcard selector
* Added Travis

## 0.1.0 / 30-04-2013
* Initial release
