QUnit.start();

test("just a test", function() {
	expect(1);
	ok(true);
});
