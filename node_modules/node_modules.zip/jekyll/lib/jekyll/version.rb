module Jekyll
  VERSION = '3.0.0-beta1'
end
