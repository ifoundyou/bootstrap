QUnit test case provided by the Qunit project at https://github.com/jquery/qunit/tree/master/test
