module Jekyll
  class Generator < Plugin
  end
end
