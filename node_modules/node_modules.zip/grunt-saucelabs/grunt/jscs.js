'use strict';

module.exports = function (grunt, options) {
  return {
    src: options.srcFiles
  };
};